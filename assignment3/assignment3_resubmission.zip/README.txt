Requirements:

Matlab basic installation
Matlab Image Processing Toolbox

Input folder tsukuba placed as in the handed in zip
archive.


How to run:

All code can be run by executing the main.m file in Matlab.


Code structure:

Code for the calculation of disparities can be found in the
file calc_disp.m.

Code for generating the gaussian pyramid can be found in the
main.m file along with all other code for the assignment.
