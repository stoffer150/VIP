Requirements:

Matlab basic installation
Matlab Image Processing Toolbox


How to run:

All code can be run by executing the main.m file in Matlab.


Code structure:

All code we have written for the assignment can be found in
the main.m file. Code that was provided for the assignment
can be found in the Matlab files unbiased_integrate.m,
simchony_integrate.m and display depth.m. We do not use
the simchony_integrate.m file for the assignment and it
can be removed without affecting the main.m file.